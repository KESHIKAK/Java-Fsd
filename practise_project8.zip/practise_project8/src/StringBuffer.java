
public class StringBuffer {

	public static void main(String[] args) {
		StringBuffer buffer = new StringBuffer ("Map");
		buffer.append("  For Beginners");
		System.out.println(buffer);
	}

}
