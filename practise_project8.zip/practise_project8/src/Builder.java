
public class Builder {

	public static void main(String[] args) {
		StringBuilder sb=new StringBuilder("Good ");
		sb.append("Evening");
		System.out.println(sb);
		// TODO Auto-generated method stub

	}

}
