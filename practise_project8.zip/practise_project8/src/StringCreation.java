
public class StringCreation {

	public static void main(String[] args) {
		String str ="HELLO INDIA";
		System.out.println(str);
	}

}
