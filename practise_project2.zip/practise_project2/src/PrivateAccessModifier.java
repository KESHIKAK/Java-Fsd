
 
public class PrivateAccessModifier {
	private String name;
	public String getName() {
        return this.name;
    }
	public void setName(String name) {
        this.name= name;
    }


    public static void main(String[] main){
    	PrivateAccessModifier d = new PrivateAccessModifier();

        // access the private variable using the getter and setter
        d.setName("Hello");
        System.out.println(d.getName());
    }
}

 
   
