
public class PublicAccessModifier {
	public int legCount;
	public void display() {
        System.out.println("I am a humanbeing.");
        System.out.println("I have " + legCount + " legs.");
    }


    public static void main( String[] args ) {
       
    	PublicAccessModifier animal = new PublicAccessModifier();

        
        animal.legCount = 2;
        
        animal.display();
    }
}


