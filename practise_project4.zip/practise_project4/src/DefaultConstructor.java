
public class DefaultConstructor {
	int x;
	  boolean y;

	public static void main(String[] args) {
		DefaultConstructor obj = new DefaultConstructor();
		System.out.println(" Value are :");
	    System.out.println("x = " + obj.x);
	    System.out.println("y = " + obj.y);
	  }
	
	}

