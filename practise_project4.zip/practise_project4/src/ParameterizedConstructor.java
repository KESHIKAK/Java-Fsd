
public class ParameterizedConstructor {
	String Animals;
	ParameterizedConstructor(String pets ) {
		Animals = pets;
	    System.out.println(Animals + " is a Pet animal ");
	  }
	
	public static void main(String[] args) {
		ParameterizedConstructor obj1 = new ParameterizedConstructor("Dog");
		ParameterizedConstructor obj2 = new ParameterizedConstructor("Cat");
		ParameterizedConstructor obj3 = new ParameterizedConstructor("Fish");
	  }
	}