
public class NoArgumentConstructor {
	String name;
	private NoArgumentConstructor () 
	{
	    name = "Santhosh";
	    System.out.println("Constructor is called");
	  }
	

	public static void main(String[] args) {
		NoArgumentConstructor obj = new NoArgumentConstructor();
	    System.out.println("Name is : " + obj.name);
	  }
	
		

	}


