
public class NarrowingTypeCasting {

	public static void main(String[] args) {
		double value = 189.55;
		long l = (long)value; 
		int i = (int)l;  
		System.out.println("Before conversion: "+value);  
		System.out.println("After conversion into long type: "+l);  
		System.out.println("After conversion into int type: "+i);
		// TODO Auto-generated method stub

	}

}
