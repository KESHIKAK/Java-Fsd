
public class WideningTypeCasting {

	public static void main(String[] args) {
		int x=8;
		long y = x;  
		float z = y;  
		// TODO Auto-generated method stub
		System.out.println("Before conversion, int value "+x);  
		System.out.println("After conversion, long value "+y);  
		System.out.println("After conversion, float value "+z);  
		}  
		  

	}


