import java.util.Map;
import java.util.HashMap;
public class Mapping {

	public static void main(String[] args) {
		 Map<String, Integer> numbers = new HashMap<>();
		 numbers.put("Ten", 10);
	        numbers.put("Thousand", 1000);
	        System.out.println("Map: " + numbers);
	        System.out.println("Keys: " + numbers.keySet());
	        System.out.println("Values: " + numbers.values());
	        System.out.println("Entries: " + numbers.entrySet());
	        int value = numbers.remove("Ten");
	        System.out.println("Removed Value: " + value);
	    }

	}

