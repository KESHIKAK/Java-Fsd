class CPU {
    double price;
    class Processor{

        // members of nested class
        double cores;
        String manufacturer;

        double getCache(){
            return 9.7;
        }
    }
    protected class RAM{
    	double memory;
        String manufacturer;

        double getClockSpeed(){
            return 4.5;
        }
    }
}
public class InnerClass {
	 public static void main(String[] args) {
		 CPU cpu = new CPU();
		 CPU.Processor processor = cpu.new Processor();
		 CPU.RAM ram = cpu.new RAM();
	        System.out.println("Processor Cache = " + processor.getCache());
	        System.out.println("Ram Clock speed = " + ram.getClockSpeed());
	    }
	
	 }


