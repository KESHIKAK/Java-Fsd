
public class Method {
	public int addNumbers(int a, int b) {
	    int output = a + b;
	    
	    return output;
	  }


	public static void main(String[] args) {
		int num1 = 10;
	    int num2 = 15;
	    Method obj = new Method();
	    int output = obj.addNumbers(num1, num2);
	    System.out.println("Sum is: " +output);
	  }
	
	}


