import java.util.ArrayList;
public class JavaCollections {

	public static void main(String[] args) {
		ArrayList<String> things = new ArrayList<>();
        // Add elements
		things.add("pen");
		things.add("pencil");
		things.add("eraser");

        System.out.println("ArrayList: " + things);
    }
}
	

	