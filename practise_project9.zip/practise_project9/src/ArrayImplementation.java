
public class ArrayImplementation {

	public static void main(String[] args) {
		Product[] obj = new Product[5] ;  
		obj[0] = new Product(101,"Pen");  
		obj[1] = new Product(998,"Pencil"); 
		obj[2] = new Product(98653,"Sketch"); 
		obj[3] = new Product(333,"Box");  
		obj[4] = new Product(1996,"Eraser");  
		System.out.println("Product Object 1:");  
		obj[0].display();  
		System.out.println("Product Object 2:");  
		obj[1].display();  
		System.out.println("Product Object 3:");  
		obj[2].display();  
		System.out.println("Product Object 4:");  
		obj[3].display();  
		System.out.println("Product Object 5:");  
		obj[4].display();  
		}  
}
class Product  
{  
int pro_Id;  
String pro_name;  
Product(int pid, String n)  
{  
pro_Id = pid;  
pro_name = n;  
}  
public void display()  
{  
System.out.print("Product Id = "+pro_Id + "  " + " Product Name = "+pro_name);  
System.out.println();  
}  
}  